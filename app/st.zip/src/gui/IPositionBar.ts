/// <reference path="../../lib/phaser.comments.d.ts"/>

interface IPositionBar {    
    updatePosition(barFractionalPosition:number): number;
}